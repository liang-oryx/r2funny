package org.r2funny.loger;

import java.util.logging.FileHandler; 
import java.util.logging.Level; 
import java.util.logging.Logger;

/**
 * ��־��¼��
 * @author liang
 *
 */

public class LTLoger {
	private static Logger	sloger = null;
	
	public static void init(){ 
		// ��ʼ��
		try {
			if (null == sloger){
				 sloger = Logger.getLogger("niosvr"); 
				 //sloger.setLevel(Level.WARNING); 
				 
				 // ���������̨��
				 //ConsoleHandler consoleHandler = new ConsoleHandler(); 
		         //consoleHandler.setLevel(Level.WARNING); 
		         //sloger.addHandler(consoleHandler); 
		         
		         FileHandler fileHandler = new FileHandler("./nio_log_" + System.currentTimeMillis() / 1000 / 60 + ".log"); 
		         fileHandler.setLevel(Level.INFO); 
		         fileHandler.setFormatter(new MyLogHander()); 
		         sloger.addHandler(fileHandler);
			}
		}catch (Exception e){
			System.out.println("LTLoger init exception:" + e.toString());
		}
	}
	
	public static void log(String strMsg){
		sloger.log(Level.INFO, strMsg);
		//sloger.info(strMsg);
	}
	
	public static void log(Level level, String strMsg){
		sloger.log(level, strMsg);
	} 
}

