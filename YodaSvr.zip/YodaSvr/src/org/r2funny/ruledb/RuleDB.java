package org.r2funny.ruledb;

import java.util.ArrayList;

public class RuleDB {
	
	private String					oryxSvrIP;			// ...
	private int						oryxSvrPort;		// ...
	
	private String					oryxAccount;		// Oryx user account
	private String					oryxPwd;			// Oryx pwd
	private String					oryxToken;			// access token
	
	private ArrayList<String >		d2GateList;			// control gate mac list
	private ArrayList<String >		urlCallbackList;	// callback seting
	private ArrayList<RuleItem>		visionRuleList;		// vision rule
	private ArrayList<RuleItem>		voiceRuleList;		// voice rule
	private ArrayList<RuleItem>		textCmdRuleList;	// text cmd rule
	
	public void init(){
		// init data 
		this.oryxSvrIP = "www.puxuntech.com";
		this.oryxSvrPort = 8686;
		
		this.oryxAccount = "iamyoda";
		this.oryxToken = "masterneedntpassword"; 
	}

	public String getOryxSvrIP() {
		return oryxSvrIP;
	}

	public void setOryxSvrIP(String oryxSvrIP) {
		this.oryxSvrIP = oryxSvrIP;
	}

	public int getOryxSvrPort() {
		return oryxSvrPort;
	}

	public void setOryxSvrPort(int oryxSvrPort) {
		this.oryxSvrPort = oryxSvrPort;
	}

	public String getOryxAccount() {
		return oryxAccount;
	}

	public void setOryxAccount(String oryxAccount) {
		this.oryxAccount = oryxAccount;
	}

	public String getOryxPwd() {
		return oryxPwd;
	}

	public void setOryxPwd(String oryxPwd) {
		this.oryxPwd = oryxPwd;
	}

	public String getOryxToken() {
		return oryxToken;
	}

	public void setOryxToken(String oryxToken) {
		this.oryxToken = oryxToken;
	}

	public ArrayList<String> getD2GateList() {
		return d2GateList;
	}

	public void setD2GateList(ArrayList<String> d2GateList) {
		this.d2GateList = d2GateList;
	}

	public ArrayList<String> getUrlCallbackList() {
		return urlCallbackList;
	}

	public void setUrlCallbackList(ArrayList<String> urlCallbackList) {
		this.urlCallbackList = urlCallbackList;
	}

	public ArrayList<RuleItem> getVisionRuleList() {
		return visionRuleList;
	}

	public void setVisionRuleList(ArrayList<RuleItem> visionRuleList) {
		this.visionRuleList = visionRuleList;
	}

	public ArrayList<RuleItem> getVoiceRuleList() {
		return voiceRuleList;
	}

	public void setVoiceRuleList(ArrayList<RuleItem> voiceRuleList) {
		this.voiceRuleList = voiceRuleList;
	}

	public ArrayList<RuleItem> getTextCmdRuleList() {
		return textCmdRuleList;
	}

	public void setTextCmdRuleList(ArrayList<RuleItem> textCmdRuleList) {
		this.textCmdRuleList = textCmdRuleList;
	}  
	
}
