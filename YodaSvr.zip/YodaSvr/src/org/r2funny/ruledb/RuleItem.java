package org.r2funny.ruledb;

public class RuleItem {
	
	public static final int		DEV_CTRL_CMD = 2;
	
	private String  ruleName;			// 
	private String  ruleDesc;			// 
	private int		ruleType;			// 
	private int		ruleInputType;		// 0 - for test 1 - wave rule  2 - vision rule , 3 - env rule  4 - text cmd
	private int		ruleOutputType;		// 0 - log 		1 - voice output  2 - control out put 3 - message post  
	private String  ruleTriggerData;	// trigger data  like  monkey king, open door
	private String  ruleTriggerOutput;	// to be continue....
	private String	calcType;			// trigger calc type, like cmp, strstr, match, bigger etc... what ever , It can working as you like...
	
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public String getRuleDesc() {
		return ruleDesc;
	}
	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}
	public int getRuleType() {
		return ruleType;
	}
	public void setRuleType(int ruleType) {
		this.ruleType = ruleType;
	}
	public int getRuleInputType() {
		return ruleInputType;
	}
	public void setRuleInputType(int ruleInputType) {
		this.ruleInputType = ruleInputType;
	}
	public int getRuleOutputType() {
		return ruleOutputType;
	}
	public void setRuleOutputType(int ruleOutputType) {
		this.ruleOutputType = ruleOutputType;
	}
	public String getRuleTriggerData() {
		return ruleTriggerData;
	}
	public void setRuleTriggerData(String ruleTriggerData) {
		this.ruleTriggerData = ruleTriggerData;
	}
	public String getRuleTriggerOutput() {
		return ruleTriggerOutput;
	}
	public void setRuleTriggerOutput(String ruleTriggerOutput) {
		this.ruleTriggerOutput = ruleTriggerOutput;
	}
	public String getCalcType() {
		return calcType;
	}
	public void setCalcType(String calcType) {
		this.calcType = calcType;
	} 
}
