package org.r2funny.ruledb;

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlDBLoader {
	
	public static RuleDB loadDB(String strFileName){
 		if (null != strFileName){
			try {
				// 
				File file = new File(strFileName);
				
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				
				Document doc = builder.parse(file);
				//Document doc = builder.parse(new ByteArrayInputStream(strXML.getBytes()));
				
				NodeList rootLn = doc.getElementsByTagName("r2db");
				
				for (int i = 0; i < rootLn.getLength(); i++) {
					RuleDB  ruleDB = new RuleDB();
					
					NodeList groupItemList = rootLn.item(i).getChildNodes();
					
					for (int k = 0; k < groupItemList.getLength(); k++){
						Node groupItem = rootLn.item(k);
						
						// get vision rule
						if ("vision".equalsIgnoreCase(groupItem.getNodeName())){
							NodeList rulesList = groupItem.getChildNodes();
							
							for (int j=0; j < rulesList.getLength(); j++){ 
								Node ruleNode = rulesList.item(j);
								// get ruleItem data
								if ("rule".equalsIgnoreCase(ruleNode.getNodeName())){
									RuleItem  ruleItem = parserRuleItem(ruleNode); 
									ruleDB.getVisionRuleList().add(ruleItem);
								}
							} 
						}
						 
						// get voice rule
						if ("voice".equalsIgnoreCase(groupItem.getNodeName())){
							NodeList rulesList = groupItem.getChildNodes();
							
							for (int j=0; j < rulesList.getLength(); j++){ 
								Node ruleNode = rulesList.item(j);
								// get ruleItem data
								if ("rule".equalsIgnoreCase(ruleNode.getNodeName())){
									RuleItem  ruleItem = parserRuleItem(ruleNode); 
									ruleDB.getVisionRuleList().add(ruleItem);
								}
							}
						}
	
						// get d2 gate mac seting
						if ("gate".equalsIgnoreCase(groupItem.getNodeName())){
							NodeList rulesList = groupItem.getChildNodes();
							for (int j=0; j < rulesList.getLength(); j++){ 
								Node ruleNode = rulesList.item(j);
								// get ruleItem data
								if ("gatemac".equalsIgnoreCase(ruleNode.getNodeName())){ 
									ruleDB.getD2GateList().add(ruleNode.getTextContent());
								}
							}
						}
						
						// get callback seting
						if ("callback".equalsIgnoreCase(groupItem.getNodeName()) ){
							NodeList rulesList = groupItem.getChildNodes();
							for (int j=0; j < rulesList.getLength(); j++){ 
								Node ruleNode = rulesList.item(j);
								// get ruleItem data
								if ("callurl".equalsIgnoreCase(ruleNode.getNodeName())){ 
									ruleDB.getUrlCallbackList().add(ruleNode.getTextContent());
								}
							} 
						}
					}
					return ruleDB;
				}
			}
			catch (Exception e){
				;
			} 
		}//if (null != strFileName)
		
		return null;
	}
	
	public static RuleItem parserRuleItem(Node ruleNode){
		return null;
 
	}
	
	
}
