package org.r2funny.yoda.easyrule;

import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Rule;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.DefaultRulesEngine;
import org.r2funny.ruledb.RuleDB;

@Rule(name = "Yoda text cmd rule", description = "The recv text cmd rule.")  
public class TextCmdEasyRule {
	
	// ��ʼ����������
	public void init(RuleDB ruleDB){
		
	}
	
    @Condition
    public boolean when() {
        return true;
    }

    @Action
    public void then() throws Exception {
        System.out.println("hello world");
    }
}
