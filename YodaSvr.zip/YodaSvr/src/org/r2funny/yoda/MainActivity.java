package org.r2funny.yoda;

 

import org.r2funny.comm.net.SocketCmdPoster;

import android.os.Bundle;
import android.app.Activity; 
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity {
	private YodaServer		yodaServer = new YodaServer();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		yodaServer.start();
		
 		View  testBtn = this.findViewById(R.id.show_info_button); 
		testBtn.setOnClickListener(new OnClickListener() { 
			@Override
			public void onClick(View v) {
				// call debug function
				yodaServer.debugCode();  
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
