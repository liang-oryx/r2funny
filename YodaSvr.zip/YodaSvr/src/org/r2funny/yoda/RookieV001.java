package org.r2funny.yoda;

import org.json.JSONObject;
import org.r2funny.ruledb.RuleDB;
import org.r2funny.yoda.easyrule.TextCmdEasyRule;
import org.r2funny.yoda.easyrule.VisionEasyRule;
import org.r2funny.yoda.easyrule.VoiceEasyRule;

public class RookieV001 implements IRookieThinker {
	
	// ����������������������
	private boolean				bInited = false;
	private TextCmdEasyRule		textCmdRules;
	private VisionEasyRule		visionRules;
	private VoiceEasyRule		voiceRules;
	
	public int think(RuleDB  ruleDB, JSONObject inputData){
		
		// ʹ�� ruledb ȥ��ʼ������EasyRule
		
		if (!bInited){
			textCmdRules.init(ruleDB);
			visionRules.init(ruleDB);
			voiceRules.init(ruleDB);
			
			this.bInited = true;
		}
		
		return 0;
	}
}
