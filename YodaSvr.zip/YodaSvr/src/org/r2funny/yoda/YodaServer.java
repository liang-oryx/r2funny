package org.r2funny.yoda;

import java.util.ArrayList;
import java.util.List;

import org.r2funny.callback.ICallbackHandler;
import org.r2funny.callback.PxCallbackHandler;
import org.r2funny.listener.VisionEnvListener;
import org.r2funny.listener.VoiceEnvListener; 
import org.r2funny.loger.LTLoger;
import org.r2funny.ruledb.RuleDB;
import org.r2funny.ruledb.RuleItem;
import org.r2funny.ruledb.XmlDBLoader;
import org.r2funny.yoda.easyrule.HelloWorld;
import org.r2funny.gate.comm.*;
import org.r2funny.gate.px.PxGateControl;

public class YodaServer implements IYodaCallbacks {
	private VisionEnvListener		visionMsgListener 	= new VisionEnvListener();
	private VoiceEnvListener		voiceEnvListener	= new VoiceEnvListener();  
	
	private List<IGateControl>		controlList			= new ArrayList<IGateControl>();
	private List<ICallbackHandler>	callbackList		= new ArrayList<ICallbackHandler>();
	
	private RuleDB					ruleDB;
	
	private IRookieThinker			brainLevel001;		//it's a very  low  ai system
	
	public void start(){
		try { 
			LTLoger.init();
			
			// load  ruleDB
			this.ruleDB = XmlDBLoader.loadDB("C:/Tmp/r2funny.xml"); 
			
			visionMsgListener.setHandler(this);
			visionMsgListener.start();
			
			voiceEnvListener.setHandler(this);
			voiceEnvListener.start();
			
			//callBackHandler.init(); 
			// init callback ...
			PxGateControl    funnyControl = new PxGateControl();
			controlList.add(funnyControl);
			
			// init smart gate control 
			PxCallbackHandler	amzCallbackHandler = new PxCallbackHandler();
			callbackList.add(amzCallbackHandler); 
			
			this.brainLevel001 = new RookieV001();
			
			WorkingThread workThread = new WorkingThread();                
			workThread.start();
		}
		catch (Exception e){
			
		}
	}
	
	public void stop(){
		// to do ... 
	}
	
	public void handleVisionMsg(String strJsonCmd){
		//
	}
	
	public void handleVoiceMsg(String strJsonCmd){
		//
	}
	
	private String  debugCmd = "";
	public void handleTextCmd(String strJsonCmd){
		// for test 
		
	}
	
	// for fun test 
	public void debugCode(){
		if (null == ruleDB){
			ruleDB = new RuleDB();
		}
		debugCmd = "&o=3&c=2";
		
		RuleItem	testRule = new RuleItem(); 
		testRule.setRuleOutputType(RuleItem.DEV_CTRL_CMD); 
		testRule.setRuleTriggerData("open door");
		
		ArrayList<RuleItem>	 textRuleList = new ArrayList<RuleItem>(); 
		textRuleList.add(testRule);
		
		ruleDB.setTextCmdRuleList(textRuleList);
		
		
		HelloWorld	forTest = new HelloWorld();
		
		forTest.testing();
	}
	
	private void thinkingIt(){
		if ((null != brainLevel001)
				&& (null != ruleDB) ){
			if (null != ruleDB.getTextCmdRuleList()){
				for (int i = 0; i < ruleDB.getTextCmdRuleList().size(); i++){
					
					RuleItem rule =  ruleDB.getTextCmdRuleList().get(i);
					
					if (RuleItem.DEV_CTRL_CMD == rule.getRuleOutputType()){
						// for test 
						if (0 < debugCmd.length()){
							postCtrlCmd(debugCmd);
							debugCmd = "";
						}
					}
				}
			}// if (null != ruleDB.getTextCmdRuleList())
			
			if (null != ruleDB.getUrlCallbackList()){
				
			}
			
			if (null != ruleDB.getVisionRuleList()){
							
			}
			
			if (null != ruleDB.getVoiceRuleList()){
				
			}
			
			// clear cur event
			// to do... 
		}
	}
	
	private void postCtrlCmd(String strCmd){
		for (int i = 0; i < controlList.size(); i++){
			controlList.get(i).postCmd(strCmd);
		}
	}
	
	// working thread .... 
	class WorkingThread extends Thread { 
		@Override 
		public void run() {
			try {
				while (true){
					thinkingIt();
					Thread.sleep(1);
				} 
			}
			catch (Exception e){
				
			}
		}
	}
}
