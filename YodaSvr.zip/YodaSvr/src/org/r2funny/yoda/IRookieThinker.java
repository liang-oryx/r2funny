package org.r2funny.yoda;

import org.json.JSONObject;
import org.r2funny.ruledb.RuleDB;

public interface IRookieThinker {
	
	public int think(RuleDB  ruleDB, JSONObject inputData);
	
}
