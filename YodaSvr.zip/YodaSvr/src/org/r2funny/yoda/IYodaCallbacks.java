package org.r2funny.yoda;

public interface IYodaCallbacks {
	// handle three type message 
	public void handleVisionMsg(String strJsonCmd);
	public void handleVoiceMsg(String strJsonCmd);
	public void handleTextCmd(String strJsonCmd);
}
