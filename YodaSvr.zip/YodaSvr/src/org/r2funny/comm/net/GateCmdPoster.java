/**
 * Copyright (C) 2018 R2Funny
 *  
 * Free 
 *  
 * Post cmd to remote gate device pass by cloud server
 * 
 */

package org.r2funny.comm.net;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
 

public class GateCmdPoster {
	private final String	R2_CLOUD_SVR_ADDR = "www.puxuntech.com";
	private final int		R2_CLOUD_UDP_PORT = 8787;
	
	private String  mTargetMac;
	private String  mTargetCtrlCmd;
	
	public void postCmd2Dev(String strTargetDevMac, String  strCmd){
		this.mTargetMac = strTargetDevMac;
		this.mTargetCtrlCmd =strCmd;
		
 		Thread cmdThread = new Thread(new PostUdpCmdDataRunnable());
 		cmdThread.start();
	}
	
    /**
     * ����Udp����
     * @author liang
     *
     */
    class PostUdpCmdDataRunnable implements Runnable{  
  	  
        @Override  
        public void run() {   
        	postGateControlCmd(mTargetMac, mTargetCtrlCmd); 
        }   
    }
    
    /**
     * ͨ�����ظ��豸��ָ��.... 
     * @param strTargetMac
     * @param strCtrlCmd
     * @return
     */
    private boolean  postGateControlCmd(String strTargetMac, String  strCtrlCmd){
    	try { 
    		String  strNetCmd = mTargetMac + "PX" + "&bypass=01&tmac=" + strTargetMac + "&len="
    						 + (32 > strCtrlCmd.length() ? ("0" + Integer.toString(strCtrlCmd.length() / 2, 16)) : Integer.toString(strCtrlCmd.length() / 2, 16))
    						 + "&dat=" + strCtrlCmd; 
    		 
    		DatagramSocket 	ds = new DatagramSocket();
    		
			DatagramPacket dp = new DatagramPacket(strNetCmd.getBytes(),   
					strNetCmd.getBytes().length, new InetSocketAddress(R2_CLOUD_SVR_ADDR, R2_CLOUD_UDP_PORT));  
			
			ds.send(dp);
    		
    		return true;
    	}
    	catch (Exception e){
    		// ���緢��ʧ��
    	}
    	return false;
    }
}
