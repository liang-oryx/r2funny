/**
 * Copyright (C) 2018 R2Funny
 *  
 * Free 
 *  
 * Post socket ctrl cmd
 * 
 */
package org.r2funny.comm.net;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

//import org.r2funny.bean.DevCtrlCmd;  

public class SocketCmdPoster {
	
	private String  targetNetAddr;
	private int		targetPort;
	
	private String  mTargetMac;
	private String  mTargetCtrlCmd;

	
	public String getTargetNetAddr() {
		return targetNetAddr;
	}
	public void setTargetNetAddr(String targetNetAddr) {
		this.targetNetAddr = targetNetAddr;
	}
	public int getTargetPort() {
		return targetPort;
	}
	public void setTargetPort(int targetPort) {
		this.targetPort = targetPort;
	}
	
	
	public void postCmd2Dev(String strTargetDevMac, String  strCmd){
		
		this.mTargetMac = strTargetDevMac;
		this.mTargetCtrlCmd =strCmd;
		
 		Thread cmdThread = new Thread(new PostUdpCmdDataRunnable());
 		cmdThread.start();
	}
	
    /**
     * ����Udp����
     * @author liang
     *
     */
    class PostUdpCmdDataRunnable implements Runnable{  
  	  
        @Override  
        public void run() {   
        	postControlCmd(mTargetMac, mTargetCtrlCmd); 
        }   
    }
    
    /**
     * ͨ�����ظ��豸��ָ��.... 
     * @param strTargetMac
     * @param strCtrlCmd
     * @return
     */
    private boolean  postControlCmd(String strTargetMac, String  strCtrlCmd){
    	try {
    		
    		// ָ��ǲ��� 
    		String  strNetCmd = strTargetMac + "PX" + strCtrlCmd; 
    		 
    		DatagramSocket 	ds = new DatagramSocket();
    		
			DatagramPacket dp = new DatagramPacket(strNetCmd.getBytes(),   
					//strNetCmd.getBytes().length, new InetSocketAddress("wx.puxuntech.com", 8787));  
					strNetCmd.getBytes().length, new InetSocketAddress("www.puxuntech.com", 8787));  
			
			ds.send(dp);
    		
    		return true;
    	}
    	catch (Exception e){
    		// ���緢��ʧ��
    	}
    	return false;
    }
    
    /*
	public boolean postCtrlCmd(DevCtrlCmd  ctrlCmd){
		try {
			
    		DatagramSocket 	ds = new DatagramSocket(); 
			DatagramPacket  dp = new DatagramPacket(ctrlCmd.getCmdData().getBytes(),   
					ctrlCmd.getCmdData().getBytes().length, new InetSocketAddress(targetNetAddr, targetPort));  
			
			ds.send(dp);
			
			return true;
		}
		catch (Exception e){
			return false;
		}
	}
	
	public boolean postCtrlCmd(String  ctrlCmdData){
		try {
			
    		DatagramSocket 	ds = new DatagramSocket(); 
			DatagramPacket  dp = new DatagramPacket(ctrlCmdData.getBytes(),   
					ctrlCmdData.getBytes().length, new InetSocketAddress(targetNetAddr, targetPort));  
			
			ds.send(dp);
			
			return true;
		}
		catch (Exception e){
			return false;
		}
	}*/
	
}
