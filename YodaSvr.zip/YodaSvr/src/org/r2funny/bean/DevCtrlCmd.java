/**
 * Copyright (C) 2018 R2Funny
 *  
 * Free 
 *  
 * �豸����ָ��
 */
package org.r2funny.bean;

public class DevCtrlCmd {
	private String		devMac;			// target  dev mac
	private int			cmdType;		// 
	private String		cmdData;		// cmd data (string )
	private int			encodeType;		// 0 - string  1 - hex16
	
	public String getDevMac() {
		return devMac;
	}
	
	public void setDevMac(String devMac) {
		this.devMac = devMac;
	}
	
	public int getCmdType() {
		return cmdType;
	}
	
	public void setCmdType(int cmdType) {
		this.cmdType = cmdType;
	}
	
	public String getCmdData() {
		return cmdData;
	}
	
	public void setCmdData(String cmdData) {
		this.cmdData = cmdData;
		this.encodeType = 0;
	}
	
	public void setCmdData(byte[] cmdData){
		this.cmdData = bytesToHexString(cmdData);
		this.encodeType = 1;
	}
	
	public int getEncodeType() {
		return encodeType;
	}
	public void setEncodeType(int encodeType) {
		this.encodeType = encodeType;
	}
	
	/*
	 * Convert byte[] to hex 
	 * 
	 * @param src byte[] data
	 * 
	 * @return hex string
	 */
	private String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder("");
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}
	
}
