package org.r2funny.listener;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
 
import org.r2funny.loger.LTLoger;
import org.r2funny.yoda.IYodaCallbacks;

public abstract class R2FunnyEnvListerner {
	
	public static final int	VISION_ENV_LISTENPORT 	= 8180;
	public static final int	VOICE_ENV_LISTENPORT 	= 8181;
	public static final int	TEXT_CMD_LISTENPORT 	= 8182; 
	
	protected int					listenPort = 0;		
	protected boolean				started = false; 
	protected IYodaCallbacks		msgHandler = null;
	
	public abstract void start();
	
	public void setHandler(IYodaCallbacks callback){
		this.msgHandler = callback;
	}
	
	
	public boolean isStarted() {
		return started;
	} 

	protected abstract void handleMsg(String strCmd);
	
	class UdpSvrThread extends Thread { 
	    private DatagramSocket 	dataSocket;
	    private DatagramPacket 	dataPacket;		// udpͨѶ��
	    private byte 			receiveByte[]; 
	    
	    public  boolean			bRuning = false;
		@Override 
		public void run() {
			try {
				
				dataSocket 	= new DatagramSocket(listenPort);
	            receiveByte = new byte[1024 * 10];	// ָ�����10K, ֻ������������
	            dataPacket 	= new DatagramPacket(receiveByte, receiveByte.length); 
	            bRuning		= true;
	            
				while (true)
				{ 
					// ��������
					dataSocket.receive(dataPacket);
	                int lRecvLen = dataPacket.getLength();
	                
	                if ((lRecvLen > 4)
	                		&& ((byte)'R' == receiveByte[0])
	                		&& ((byte)'2' == receiveByte[1])
	                		&& ((byte)'F' == receiveByte[2])
	                		&& ((byte)'U' == receiveByte[3])
	                		&& ((byte)'N' == receiveByte[4]) ){
	                	
	                	// cmd is json;
	                	String  strJson = new String(receiveByte, 5, dataPacket.getLength() - 5);
	                	handleMsg(strJson);
	                }
	                 
				}
			} catch (Exception e){
				System.out.println("Exception in UdpSvrThread:" + e.toString());
				LTLoger.log("Exception in UdpSvrThread:" + e.toString());
					
				dataSocket.close();
				bRuning = false;
				
			} 
		}
	}
}
