package org.r2funny.listener;


import org.r2funny.loger.LTLoger; 

public class VisionEnvListener extends R2FunnyEnvListerner {
	
	public void start(){
		try { 
			this.listenPort = VISION_ENV_LISTENPORT;
    		UdpSvrThread udpSvrThread = new UdpSvrThread();                
    		udpSvrThread.start();
    		started = true;
    	}catch (Exception e){
    		LTLoger.log("VisionEnvListener start exception:" + e.toString());
    	} 
	}
	
	protected void handleMsg(String strCmd){
		if (null != this.msgHandler){
			this.msgHandler.handleVisionMsg(strCmd);
		}
	} 
}
