
package org.r2funny.callback;

public interface ICallbackHandler {
	
	public int handleUrlCallback(String strUrl, String strParam);
}
