/**
 * the callback handler of puxuntech.com orxy svr
 */
package org.r2funny.callback;

public class PxCallbackHandler implements ICallbackHandler {

	public void init(){
		
	}
	
	public int handleUrlCallback(String strUrl, String strParam){
		return -1;
	}
}
