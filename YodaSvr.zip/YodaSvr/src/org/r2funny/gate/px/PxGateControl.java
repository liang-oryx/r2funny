/**
 * ר���ڿ�����Ѷ�Ƽ��������صĿ����� 
 */
package org.r2funny.gate.px;

import java.util.ArrayList;
import java.util.List;

import org.r2funny.comm.net.SocketCmdPoster;
import org.r2funny.gate.comm.IGateControl;

public class PxGateControl implements IGateControl {
	
	private String					dynamicCode		= "free for yoda master";
	private String					ctrlToken		= "";
	
	private SocketCmdPoster			cmdPoster		= new SocketCmdPoster();
	private ArrayList<String>		gateRepDataList = new ArrayList<String>();
	
	// gate init
	public boolean init(String  strParam){
		this.ctrlToken = strParam;
		return true;
	}
	
	// access the gate data
	public List<String>  getInfo(){
		return this.gateRepDataList;
	}
	
	// post cmd by gate 
	public boolean postCmd(String strCmd){ 
 		// debug code 
		cmdPoster.postCmd2Dev("cbef871080c6", strCmd);
		
		return true;
	}

}
