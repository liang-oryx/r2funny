package org.r2funny.gate.comm;

import java.util.List;

public interface IGateControl {
	// gate init
	public boolean init(String  strParam);
	
	// access the gate data
	public List<String>  getInfo();
	
	// post cmd by gate 
	public boolean postCmd(String strCmd);
	
	
}
