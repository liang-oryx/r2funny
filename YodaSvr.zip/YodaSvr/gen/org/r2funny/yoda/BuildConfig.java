/** Automatically generated file. DO NOT MODIFY */
package org.r2funny.yoda;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}